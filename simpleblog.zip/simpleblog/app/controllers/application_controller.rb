class PostsController < ApplicationController
  before_action :find_post, only: [:edit, :update, :show, :delete]

  # Index action to render all posts
  def index
    @documents = Document.all
  end

  # New action for creating post
  def new
    @document = Document.new
  end

  # Create action saves the post into database
  def create
    @document = Document.new
    if @document.save(post_params)
      flash[:notice] = "Successfully created post!"
      redirect_to post_path(@document)
    else
      flash[:alert] = "Error creating new post!"
      render :new
    end
  end

  # Edit action retrives the post and renders the edit page
  def edit
  end

  # Update action updates the post with the new information
  def update
    if @document.update_attributes(post_params)
      flash[:notice] = "Successfully updated post!"
      redirect_to post_path(@documents)
    else
      flash[:alert] = "Error updating post!"
      render :edit
    end
  end

  # The show action renders the individual post after retrieving the the id
  def show
  end

  # The destroy action removes the post permanently from the database
  def destroy
    if @document.destroy
      flash[:notice] = "Successfully deleted post!"
      redirect_to posts_path
    else
      flash[:alert] = "Error updating post!"
    end
  end

  private

  def post_params
    params.require(:document).permit(:title, :body)
  end

  def find_post
    @document = Document.find(params[:id])
  end
end