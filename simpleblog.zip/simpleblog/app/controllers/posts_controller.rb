class PostsController < ApplicationController
  def index
    @documents = Document.order("published_at DESC")
  end

  def show
    @document = Document.find(params[:id])
  end
end