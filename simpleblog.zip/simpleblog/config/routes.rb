MarkdownExample::Application.routes.draw do
  resources :documents, only: [:index, :show]
  root to: "documents#index"
end